#!/bin/bash

# ==============================
# UPDATE SCRIPT WITH LOADING
# ==============================

# warna
RED='\033[1;31m'
GREEN='\033[1;32m'
YELLOW='\033[1;33m'
BLUE='\033[1;34m'
CYAN='\033[1;36m'
WHITE='\033[1;37m'
NC='\033[0m'

# progress bar
progress() {
    local percent=$1
    local width=40
    local filled=$((percent * width / 100))
    local empty=$((width - filled))

    printf "\r${CYAN}["
    printf "%0.s#" $(seq 1 $filled)
    printf "%0.s-" $(seq 1 $empty)
    printf "]${NC} ${WHITE}%3d%%${NC}" "$percent"
}

finish() {
    echo ""
}

clear
echo -e "${WHITE}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${NC}"
echo -e "${GREEN}            UPDATE SCRIPT SEDANG BERJALAN        ${NC}"
echo -e "${WHITE}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${NC}"
echo ""

sleep 1

# ==============================
# START UPDATE
# ==============================

progress 5
sleep 0.3

echo -e "\n${YELLOW}Menghapus file lama...${NC}"
rm -rf /usr/local/sbin/menu* >/dev/null 2>&1
sleep 0.5
progress 20

echo -e "\n${YELLOW}Download file update...${NC}"
wget -q https://raw.githubusercontent.com/Andyyuda/v4/main/menu/menu.zip -O menu.zip

if [[ ! -f "menu.zip" ]]; then
    finish
    echo -e "${RED}Gagal download file update!${NC}"
    exit 1
fi

sleep 0.5
progress 40

echo -e "\n${YELLOW}Extract file...${NC}"
unzip -o menu.zip >/dev/null 2>&1

if [[ ! -d "menu" ]]; then
    finish
    echo -e "${RED}Gagal extract file!${NC}"
    exit 1
fi

sleep 0.5
progress 65

echo -e "\n${YELLOW}Set permission...${NC}"
chmod +x menu/*

sleep 0.5
progress 80

echo -e "\n${YELLOW}Install ke system...${NC}"
mv menu/* /usr/local/sbin/

sleep 0.5
progress 95

echo -e "\n${YELLOW}Membersihkan file sementara...${NC}"
rm -rf menu
rm -f menu.zip

sleep 0.5
progress 100
finish

echo ""
echo -e "${GREEN}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${NC}"
echo -e "${GREEN}         UPDATE BERHASIL ✔️                       ${NC}"
echo -e "${GREEN}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${NC}"
echo ""
echo -e "${WHITE}Silakan jalankan ulang menu.${NC}"
echo ""